Welcome to the 411/413 final exam!  Here's the rules:

4. Extra credit is available!  That's explained at the bottom of this file.
   The extra credit survey can be done *after* the project is submitted.

Good luck!!!


--------------------------------------------------------------


- EXTRA CREDIT.  As you probably know, we've been doing research on group formation
  this year.  We hope to get better and better at forming groups that work well together
  and that support excellent learning and work.

  The extra credit (applied toward this final exam) is to fill out the survey one
  more time now that the core is over.  We're asking for your name so we can connect
  your surveys, but the data will be anonymized before we share with other
  professors.  The survey is here:

       https://byu.az1.qualtrics.com/jfe/form/SV_0Jm7w33las8bPhj




 _|_|_|_|_|  _|                            _|                  _|  _|  _|
     _|      _|_|_|      _|_|_|  _|_|_|    _|  _|      _|_|_|  _|  _|  _|
     _|      _|    _|  _|    _|  _|    _|  _|_|      _|_|      _|  _|  _|
     _|      _|    _|  _|    _|  _|    _|  _|  _|        _|_|
     _|      _|    _|    _|_|_|  _|    _|  _|    _|  _|_|_|    _|  _|  _|
