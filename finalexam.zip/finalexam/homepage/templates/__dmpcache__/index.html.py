# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1524257703.6367218
_enable_loop = True
_template_filename = '/Users/brand/Desktop/finalexam/homepage/templates/index.html'
_template_uri = 'index.html'
_source_encoding = 'utf-8'
import django_mako_plus
_exports = ['content']


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'base.htm', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        prices = context.get('prices', UNDEFINED)
        form = context.get('form', UNDEFINED)
        def content():
            return render_content(context._locals(__M_locals))
        __M_writer = context.writer()
        __M_writer('\n\n')
        if 'parent' not in context._data or not hasattr(context._data['parent'], 'content'):
            context['self'].content(**pageargs)
        

        __M_writer('\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


def render_content(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        prices = context.get('prices', UNDEFINED)
        form = context.get('form', UNDEFINED)
        def content():
            return render_content(context)
        __M_writer = context.writer()
        __M_writer('\n    <h1>Search Crypto:</h1>\n\n    <div id="form_container">\n        ')
        __M_writer(str( form ))
        __M_writer('\n\n        <div class="text-center">\n            <button id="start_date_button" class="btn btn-default">Set Starting Date</button>\n            <button id="end_date_button" class="btn btn-default">Set Ending Date</button>\n        </div>\n    </div>\n    <div id="results_container">\n')
        __M_writer('        <table>\n          <thead>\n            <tr>\n              <th class="results">\n                Symbol\n              </th>\n              <th class="results">\n                Date\n              </th>\n              <th class="results">\n                Price\n              </th>\n            </tr>\n          </thead>\n          <tbody>\n')
        for row in prices:
            __M_writer('            <tr>\n              <td class="results">\n                ')
            __M_writer(str( row.symbol ))
            __M_writer('\n              </td>\n              <td class="results">\n                ')
            __M_writer(str( row.date ))
            __M_writer('\n              </td>\n              <td class="results">\n                ')
            __M_writer(str( row.price ))
            __M_writer('\n              </td>\n            </tr>\n')
        __M_writer('          </tbody>\n        </table>\n    </div>\n\n')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "/Users/brand/Desktop/finalexam/homepage/templates/index.html", "uri": "index.html", "source_encoding": "utf-8", "line_map": {"28": 0, "37": 1, "42": 50, "48": 3, "56": 3, "57": 7, "58": 7, "59": 18, "60": 33, "61": 34, "62": 36, "63": 36, "64": 39, "65": 39, "66": 42, "67": 42, "68": 46, "74": 68}}
__M_END_METADATA
"""
